from django.contrib import admin

# Register your models here.
from .models import Candidate, Position, User, Vote

admin.site.register(Position)
admin.site.register(Candidate)
admin.site.register(User)
admin.site.register(Vote)