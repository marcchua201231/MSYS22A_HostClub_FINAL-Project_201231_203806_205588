from secrets import choice
from turtle import position
from django.shortcuts import render, redirect, get_object_or_404
from .models import User, Candidate, Position, Vote
from django.contrib import messages

if(len(User.objects.all()) > 0):
    loggedInUser = User.objects.all()[0]

# Create your views here.
def hello_world(request):
    return render(request, 'Halalan2022/hello_world.html')

def home(request):
    global loggedInUser
    pres_candidates = Candidate.objects.filter(position_id = 1)
    vp_candidates = Candidate.objects.filter(position_id  = 2)
    leni_vote = len(Vote.objects.filter(choice_id = 1))
    bbm_vote = len(Vote.objects.filter(choice_id = 2))
    ping_vote = len(Vote.objects.filter(choice_id = 3))
    isko_vote = len(Vote.objects.filter(choice_id = 4))
    leody_vote = len(Vote.objects.filter(choice_id = 5))
    manny_vote = len(Vote.objects.filter(choice_id = 6))
    kiko_vote = len(Vote.objects.filter(choice_id = 7))
    sarah_vote = len(Vote.objects.filter(choice_id = 8))
    ong_vote = len(Vote.objects.filter(choice_id = 9))
    sotto_vote = len(Vote.objects.filter(choice_id = 10))
    #vp_candidate_vote = zip([len(Vote.objects.filter(choice_id = 7)),len(Vote.objects.filter(choice_id = 8)),len(Vote.objects.filter(choice_id = 9)),len(Vote.objects.filter(choice_id = 10))])
    return render(request, 'Halalan2022/home.html', {'liu': loggedInUser, 'pres_candidates' : pres_candidates, 'vp_candidates' : vp_candidates, 'leni_vote' : leni_vote, 'bbm_vote' : bbm_vote, 'ping_vote' : ping_vote, 'isko_vote' : isko_vote, 'leody_vote' : leody_vote, 'manny_vote' : manny_vote, 'kiko_vote' : kiko_vote, 'sarah_vote' : sarah_vote, 'ong_vote' : ong_vote, 'sotto_vote' : sotto_vote })

def users(request, pk):
    #user_page_objects = User.objects.all()
    liu = get_object_or_404(User, pk=pk)
    user_votes = Vote.objects.filter(voter_id = pk)
    return render(request, 'Halalan2022/users.html' , {'liu': liu, 'user_votes' : user_votes})

def candidates(request):
    global loggedInUser
    candidate_page_objects = Candidate.objects.all()
    return render(request, 'Halalan2022/candidates.html', {'candidates': candidate_page_objects, 'liu': loggedInUser})

def vote(request):
    global loggedInUser
    #liu = get_object_or_404(User, pk=pk)
    position_page_objects = Position.objects.all()
    return render(request, 'Halalan2022/vote.html', {'positions' : position_page_objects, 'liu': loggedInUser})

def about(request):
    global loggedInUser
    return render(request, 'Halalan2022/about.html', {'liu': loggedInUser})

def login(request):
    if(request.method == "POST"):
        acc_username = request.POST.get('username')
        acc_password = request.POST.get('password')

        accountList = User.objects.filter(username = acc_username)

        #if(len(User.objects.filter(username = acc_username, password = acc_password)) > 0):
        if(len(accountList) > 0):
            authenticateUser = accountList[0]
            
            if (authenticateUser.getPassword() == acc_password):
                global loggedInUser
                loggedInUser = authenticateUser
                messages.success(request, 'SUCCESSFUL LOGIN')
                return redirect('home')
            else: 
                messages.info(request, 'INVALID LOGIN')
                return render(request, 'Halalan2022/login.html')
            
        else:
            messages.info(request, 'INVALID LOGIN')
            return render(request, 'Halalan2022/login.html')
    else:
        return render(request, 'Halalan2022/login.html')

def signup(request):
    if(request.method == "POST"):
        acc_username = request.POST.get('username')
        acc_password = request.POST.get('password')
        acc_first_name = request.POST.get('first_name')
        acc_last_name = request.POST.get('last_name')
        acc_birthday = request.POST.get('birthday')
        acc_sex = request.POST.get('sex')

        accountList = User.objects.filter(username = acc_username)
        if(len(accountList) > 0):
            messages.info(request, 'USERNAME IS ALREADY TAKEN')
            return render(request, 'Halalan2022/signup.html')
        else:
            User.objects.create(username = acc_username, password = acc_password, first_name = acc_first_name, last_name = acc_last_name, birthday = acc_birthday, sex = acc_sex)
            messages.info(request, 'RECORD SUCCESSFULLY CREATED')
            return redirect('login')
    else:
        return render(request, 'Halalan2022/signup.html')

def edit_details(request, pk):
    #liu = get_object_or_404(User, pk=pk)
    global loggedInUser

    if(request.method == "POST"):
        new_username = request.POST.get('username')
        new_password = request.POST.get('password')
        new_first_name = request.POST.get('first_name')
        new_last_name = request.POST.get('last_name')
        new_birthday = request.POST.get('birthday')
        new_sex = request.POST.get('sex')
        
        User.objects.filter(pk=pk).update(username = new_username, password = new_password, first_name = new_first_name, last_name = new_last_name, birthday = new_birthday, sex = new_sex)
        messages.info(request, 'SUCCESSFULLY UPDATED Details')
        return redirect('users', pk=pk)
    else:
        return render(request, 'Halalan2022/edit_details.html', {'liu': loggedInUser})

def vote_check(request, pk):
    global loggedInUser
    all_candidates = Candidate.objects.all()
    #liu = get_object_or_404(User, pk=pk)
    if(request.method == "POST"):
        pres_pk = int(request.POST.get('president'))
        comment_pres = request.POST.get("pres_comment")

        vp_pk = int(request.POST.get('vice_president'))
        comment_vice = request.POST.get("vp_comment")
        
        #vote_pres = all_candidates.filter(pk=pres_pk)
        if(Vote.objects.filter(voter_id = pk).exists()):
            messages.info(request, "YOU HAVE ALREADY VOTED!")
            return render(request, 'Halalan2022/vote.html',{'liu': loggedInUser})
        elif(pres_pk == -1 or vp_pk == -1):
            messages.info(request, "CHOOSE A CANDIDATE. TRY AGAIN!")
            return render(request, 'Halalan2022/vote.html',{'liu': loggedInUser})
        else:
            Vote.objects.create(choice_id = pres_pk, voter_id = pk, comment=comment_pres)
            Vote.objects.create(choice_id = vp_pk, voter_id = pk, comment=comment_vice)
            messages.success(request, "VOTING SUCCESSFUL")
            return redirect('users', pk=pk)
   
    else:
        return render(request, 'Halalan2022/vote.html',{'liu': loggedInUser})

def home_signout(request):
    return render(request, 'Halalan2022/homesignout.html')

#def delete_account(request, pk):
#    User.objects.filter(pk=pk).delete()
#    return redirect('login')