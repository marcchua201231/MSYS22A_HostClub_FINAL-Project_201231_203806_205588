from django.db import models

# Create your models here.
class Position(models.Model):
    name = models.CharField(max_length=200)
    #pub_date = models.DateTimeField('date published', null=True)
    objects = models.Manager()

    def getName(self):
        return self.name

    def __str__(self):
        return "Position Name: " + self.name 

class Candidate(models.Model):
    first_name = models.CharField(max_length=300, default='')
    last_name = models.CharField(max_length=300, default='')
    nickname = models.CharField(max_length=300, default='')
    slogan = models.CharField(max_length=300, default='')
    position = models.ForeignKey(Position, on_delete=models.CASCADE)
    objects = models.Manager()
    #choice_text = models.CharField(max_length=200)
    #votes = models.IntegerField(default=0)

    def getFirstName(self):
        return self.first_name
    def getLastName(self):
        return self.last_name
    def getNickname(self):
        return self.nickname
    def Slogan(self):
        return self.slogan
    def __str__(self):
        #return f"{str(self.pk)} : {self.position.name}, {self.first_name} {self.last_name}, {self.nickname}, {self.slogan}"
        return str(self.pk) + ": " + str(self.position.name) + ", " + self.first_name + " " + self.last_name + ", " + self.nickname + ", " + self.slogan
        #Pk: Candidate PK: position, first_name last_name, nickname, slogan

class User(models.Model):
    username = models.CharField(max_length=300)
    password = models.CharField(max_length=300)
    first_name = models.CharField(max_length=300)
    last_name = models.CharField(max_length=300)
    birthday = models.DateField()
    sex = models.CharField(max_length=300)
    objects = models.Manager()

    def getUsername(self):
        return self.username

    def getPassword(self):
        return self.password

    def getFirstName(self):
        return self.first_name

    def getLastName(self):
        return self.last_name 

    def getBirthday(self):
        return str(self.birthday)

    def getSex(self):
        return self.sex 
    
    def getPK(self):
        return self.pk

    def __str__(self):
        return str(self.pk) + ": " + self.username + ", " + self.first_name + " " + self.last_name + ", " + str(self.birthday) + ", " + self.sex
        # pk: User PK: username, first_name last_name, birthday, sex

class Vote(models.Model):
    choice = models.ForeignKey(Candidate,on_delete=models.CASCADE)
    voter = models.ForeignKey(User,on_delete=models.CASCADE)
    comment = models.CharField(max_length=300)

    def getComment(self):
        return self.comment
    
    def __str__(self):
        return str(self.pk) + ": " + str(self.choice.position.name + ": " + self.choice.first_name + " " + self.choice.last_name) + ". " + self.comment
        # pk: Vote PK: Position Name: Candidate: Candidate Name. comment
        # pk: 1: President: Candidate: Juan Dela Cruz. He is good.